package com.trading.TradeApp.trade_api;

public class TraderDTO {

	
	public TraderDTO(Object object) {
		
	}

	
}
