package com.trading.TradeApp.trade_api;

public class AddMoneyTraderDTO {

}
