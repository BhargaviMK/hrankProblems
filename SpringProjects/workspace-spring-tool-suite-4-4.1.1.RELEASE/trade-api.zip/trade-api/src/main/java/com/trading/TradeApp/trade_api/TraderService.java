package com.trading.TradeApp.trade_api;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.validation.Valid;

import org.springframework.stereotype.Service;

@Service
public class TraderService {
		
	private List<Trader> tradersList = new ArrayList<>();
	
	
	public void registerTrader(@Valid Trader trader) {
			tradersList.add(trader);
	}

	public void deleteTraderById(Long id) {
		tradersList.removeIf(t->t.getId().equals(id));
	}

	public void deleteTraderByEmail(String email) {
		tradersList.removeIf(t->t.getEmail().equals(email));
	}

	public Object getTraderById(Long id) {
		
		return null;
	}

	public Object getTraderByEmail(String email) {
		
		return null;
	}

	public Collection<TraderDTO> getAllTraders() {
		
		return null;
	}

	public void updateTrader(@Valid UpdatedTraderDTO trader) {
		
		
	}

	public void addMoney(@Valid AddMoneyTraderDTO trader) {
		// TODO Auto-generated method stub
		
	}

}
