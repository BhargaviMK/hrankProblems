package com.rest.sample.login.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SampleLoginApplicationController {
	
	@GetMapping("/login/{username}/{password}")
	public void checkLogin(@PathVariable String username, @PathVariable String password)
	{
		
		//if(username.equals("manu") && password.equals("bannu"))
		 //true;
		//else
		//return false;
	}

}
