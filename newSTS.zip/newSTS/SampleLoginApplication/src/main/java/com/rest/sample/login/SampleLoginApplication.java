package com.rest.sample.login;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SampleLoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(SampleLoginApplication.class, args);
	}

}
