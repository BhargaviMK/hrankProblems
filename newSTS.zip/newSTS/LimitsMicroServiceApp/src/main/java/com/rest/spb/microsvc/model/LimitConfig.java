package com.rest.spb.microsvc.model;

public class LimitConfig {


	private int minm;
	private int maxm;
	
	public int getMaxm() {
		return maxm;
	}
	public void setMaxm(int max) {
		this.maxm = max;
	}
	public int getMinm() {
		return minm;
	}
	public void setMinm(int min) {
		this.minm = min;
	}
	public LimitConfig(int min, int max) {
		super();
		this.minm = min;
		this.maxm = max;
	}
	
	protected LimitConfig() {}
}
