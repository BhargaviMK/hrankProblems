package com.rest.spb.microsvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class LimitsMicroServiceAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(LimitsMicroServiceAppApplication.class, args);
	}

}
