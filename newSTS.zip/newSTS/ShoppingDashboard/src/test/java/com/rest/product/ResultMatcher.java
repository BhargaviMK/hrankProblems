package com.rest.product;

public class ResultMatcher {

	public static boolean matchJson(String contentAsString, String res, boolean b) {
		// TODO Auto-generated method stub
		return false;
	}

	public static boolean matchJsonArray(String contentAsString, String res, boolean b) {
		// TODO Auto-generated method stub
		return false;
	}

}
