package com.rest.product;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoppingDashboardApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShoppingDashboardApplication.class, args);
	}

}
