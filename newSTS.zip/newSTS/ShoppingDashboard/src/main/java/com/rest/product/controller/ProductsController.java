package com.rest.product.controller;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.rest.product.model.Product;

@RestController
public class ProductsController{
	
	@Autowired
	ProductsRepo repo;
	
	@PostMapping("/products")
	public ResponseEntity<Object> addProduct(@RequestBody Product p)
	{
		Optional<Product> s = repo.findById(p.getId());
		if(s.isPresent())
		 return ResponseEntity.badRequest().build();//400
		else
		{
		repo.save(p);
		return ResponseEntity.status(HttpStatus.CREATED).build();//201
		}
	}
	
	@PutMapping("/products/{product_id}")
	public ResponseEntity<Object> updateProduct(@RequestBody Product p, @PathVariable Long product_id)
	{
		Optional<Product> s = repo.findById(product_id);
		if(s.isPresent()) {
		 repo.save(p);
		 return ResponseEntity.ok().build();//200
		}
		else
		return ResponseEntity.badRequest().build();//400
	}
	
	@GetMapping("/products")
	public ResponseEntity<List<Product>> retrieveAllProducts()
	{
		List<Product> pl = repo.findAll();
		pl.sort((p1, p2)->p1.getId().compareTo(p2.getId()));
		
		return ResponseEntity.ok(pl);//200
		
	}
	
	@GetMapping("/products/id/{product_id}")
	public  ResponseEntity<Object> retrieveProductByID(@PathVariable Long product_id)
	{
		Optional<Product> p = repo.findById(product_id);
		
		if(p.isPresent())
			return ResponseEntity.ok(p);
		else
			return ResponseEntity.notFound().build();
	}
	
	@GetMapping("/products/category/{category}")
	public ResponseEntity<List<Product>> retrieveProductByCategory(@PathVariable String category)
	{
		//availability
		Comparator<Product> compareByAvailabilty = Comparator.comparing(Product::getAvailability);
		 
		//discount comparator
		Comparator<Product> compareByDiscount = Comparator.comparing(Product::getDiscountedPrice);
		Comparator<Product> compareByAvailabiltyDiscount = compareByAvailabilty.thenComparing(compareByDiscount);
		 
	List<Product> pl = repo.findAllByCategory(category)
		.stream()
        .sorted(compareByAvailabiltyDiscount)
        .sorted((p1, p2)->p1.getId().compareTo(p2.getId()))
        .collect(Collectors.toList());
		
	return ResponseEntity.ok(pl);
		
	}
	
	@GetMapping("/products/category={category}/availability={availability}")
	public List<Product> retrieveProductByCategoryAndAvailability(@PathVariable String category, @PathVariable Boolean availability)
	{
		return null;
		//return repo.findByCategoryAndAvailability();
		
	}
}
