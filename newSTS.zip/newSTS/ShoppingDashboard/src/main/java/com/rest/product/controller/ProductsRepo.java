package com.rest.product.controller;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.rest.product.model.Product;

@Repository
public interface ProductsRepo extends JpaRepository<Product, Long>{
	
	public List<Product> findAllByCategory(String Category);
	public List<Product> findAllByCategoryAndAvailability(String Category,Boolean Availability);

}
