package com.rest.spb.Student;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentRestServiceApp1Application {

	public static void main(String[] args) {
		SpringApplication.run(StudentRestServiceApp1Application.class, args);
	}

}
