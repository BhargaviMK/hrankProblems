package firstSpringBootApp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AppController {
	
	//AppService as = new AppService();
	
	//let spring give you the bean
	@Autowired
	AppService serviceObj;
	
	//@RequestMapping is equivalent to @RequestMapping("/")
	@RequestMapping
	public String welcome()
	{
		
		return "Welcome to the Peace";
	}
	
	@RequestMapping("/welcome")
	public String realWelcome()
	{
		
		return serviceObj.sayWelcome();
	}
	
	@RequestMapping("/welcome")
	public String realWelcome1()
	{
		
		return serviceObj.sayWelcome();
	}
}

@Service
class AppService{
	
	public String sayWelcome()
	{
		return "oh Wow !! AutoWiring";
	}
	
	
	
}
