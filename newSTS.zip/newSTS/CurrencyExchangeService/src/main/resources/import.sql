insert into exchange_value(id, currency_from, currency_to, conversion_multiple,port) values(10001, 'usd','inr',75.0,0);
insert into exchange_value(id, currency_from, currency_to, conversion_multiple,port) values(10002, 'sgd','inr',65.0,0);
insert into exchange_value(id, currency_from, currency_to, conversion_multiple,port) values(10003, 'aud','inr',25.0,0);