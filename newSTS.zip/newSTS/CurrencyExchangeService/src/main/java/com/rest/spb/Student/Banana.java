
package com.rest.spb.Student;

class Banana{
	
	public static void main(String... args){
	int b =127;
	b+=3;
	b+=1.5;
	System.out.println(b);
	}
}

