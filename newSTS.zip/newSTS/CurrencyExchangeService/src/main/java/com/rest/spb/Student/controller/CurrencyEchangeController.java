package com.rest.spb.Student.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.rest.spb.Student.model.ExchangeValue;
import com.rest.spb.Student.repo.ExchangeValueRepository;

@RestController
public class CurrencyEchangeController {
	
	@Autowired
	Environment env;
	
	@Autowired
	ExchangeValueRepository exRepo;
	
	@GetMapping("/currency-exchange/from/{from}/to/{to}")
	public ExchangeValue retrieveExchangeValue(@PathVariable String from, @PathVariable String to) {
		
		
		//ExchangeValue exchangeValue = new ExchangeValue(1000L, from, to, BigDecimal.valueOf(65));
		ExchangeValue exchangeValue = exRepo.findByFromAndTo(from,to);
		exchangeValue.setPort(env.getProperty("local.server.port"));
		return exchangeValue;
	}
}
	
