package utilspkg;

public class BitUtils {
	
	private static void process(byte[] b)
	{
		
	}

}
