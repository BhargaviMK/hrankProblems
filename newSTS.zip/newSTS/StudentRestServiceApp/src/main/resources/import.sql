insert into student values(1,sysdate, 'bannu');
insert into student values(2, sysdate,'vittu' );
insert into student values(3, sysdate,'manu');

insert into course values(11,'java', 'ranga', 1);
insert into course values(12, 'spring','rao', 1);
insert into course values(13, 'boot','karanam', 1);