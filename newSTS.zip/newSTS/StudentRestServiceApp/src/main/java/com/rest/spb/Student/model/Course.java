package com.rest.spb.Student.model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Course{
	
	@Id
	@GeneratedValue
	private int cid;
	private String cname;
	private String clecturer;
	
	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY)
	private Student stu; 

	public Student getStu() {
		return stu;
	}
	public void setStu(Student stu) {
		this.stu = stu;
	}
	public Course()
	{
		
	}
	public Course(int cid, String cname, String clecturer) {
		super();
		this.cid = cid;
		this.cname = cname;
		this.clecturer = clecturer;
	}

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getClecturer() {
		return clecturer;
	}

	public void setClecturer(String clecturer) {
		this.clecturer = clecturer;
	}

	
	
}
