package com.rest.spb.Student.service;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.CONFLICT)
public class StudentNotFoundException extends Exception {
	
	public StudentNotFoundException(String message)
	{
		super(message);
	}
	
}
