package com.rest.spb.Student.controller;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

import java.net.URI;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.rest.spb.Student.model.Course;
import com.rest.spb.Student.model.Student;
import com.rest.spb.Student.service.StudentDaoService;
import com.rest.spb.Student.service.StudentNotFoundException;

@RestController
public class StudentJPAController {
	@Autowired
	StudentDaoService service;
	
	@Autowired
	StudentRepository srepo;
	
	@Autowired
	CourseRepository crepo;
//	
	@GetMapping("jpa/students")
	public List<Student> getAllUsers() {
		return srepo.findAll();
	}

	@GetMapping("jpa/students/{sid}")
	public Resource<Student> getUser(@PathVariable int sid) throws StudentNotFoundException {
		System.out.println("Student??");
		Optional<Student> s = srepo.findById(sid);
		System.out.println(s == null ?"Student? is null" :s );
		if(!s.isPresent()) {
		throw new StudentNotFoundException("User is not found with "+sid);
		}
		//HATEOAS
//		{
//	    "id": 1,
//	    "name": "Ban1",
//	    "date": "2019-04-21T06:45:12.398+0000",
//	    "_links": {
//	        "all-users": {
//	            "href": "http://localhost:9875/students"
//	        }
//	    }
//	} 
	//To achieve that link use hateoas
		Resource<Student> r = new Resource<Student>(s.get());
		r.add(linkTo(methodOn(this.getClass()).getAllUsers()).withRel("all-students"));
		r.add(linkTo(methodOn(this.getClass()).getAllCourses(sid)).withRel("all-courses for id "+sid));
		
		return r;
	}

	// return created 201 status
	@PostMapping("jpa/students")
	public ResponseEntity<Object> createUser(@Valid @RequestBody Student student) {
		Student temp = srepo.save(student);

		// self link making
		URI self = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(temp.getId()).toUri();
		
		//created method represents CREATED==201
		//return ResponseEntity.created(self).build();
		
		//send the object to response
		return ResponseEntity.created(self).body(temp);
	}

	@PutMapping("jpa/students")
	public Student updateUser(@RequestBody Student student) {
		return srepo.save(student);
	}


	@DeleteMapping("jpa/students/{sid}")
	public void deleteUser(@PathVariable int sid) throws StudentNotFoundException {
		 srepo.deleteById(sid);
//		if(s == null)
//			throw new StudentNotFoundException("No Student is Available with " +sid +" to deletes");
//			
	}
	
	@GetMapping("jpa/students/{sid}/courses")
	public List<Course> getAllCourses(@PathVariable int sid) throws StudentNotFoundException
	{
		
	Optional<Student> sto = srepo.findById(sid);
	if(!sto.isPresent())
		throw new StudentNotFoundException("Student does not exist with id in DB");
	else
	{
		List<Course> clist = sto.get().getCourse();
		return clist;
	}
	}
	
	@PostMapping("jpa/students/{sid}/courses")
	public Course createCourseForStudent(@PathVariable int sid, @RequestBody Course course) throws StudentNotFoundException
	{
		Optional<Student> sto = srepo.findById(sid);
		course.setStu(sto.get());
		System.out.println("Course" );
		if(!sto.isPresent())
			throw new StudentNotFoundException("Student does not exist with this id in DB");
		else
		{
			Course savedCourse = crepo.save(course);
		/*	if(savedCourse==null)throw new Exception("hi");*/
		// when you want to throw exceptions more than one use super type exception class or surround with try catch
			return savedCourse;
		}
		
	}

}
