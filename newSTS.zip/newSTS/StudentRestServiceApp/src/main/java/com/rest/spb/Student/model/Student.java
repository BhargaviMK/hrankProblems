package com.rest.spb.Student.model;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.validation.constraints.Past;
import javax.validation.constraints.Size;

@Entity
public class Student {
	
	@Id
	@GeneratedValue
	private Integer id;
	
	@Size(min = 2, message = "Min length is 2 chars for input Name")
	private String name;
	
	@Past
	private Date date;
	
	@OneToMany(mappedBy="stu")
	private List<Course> course;
	
	public List<Course> getCourse() {
		return course;
	}
	public void setCourse(List<Course> course) {
		this.course = course;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public Student(Integer id, String name, Date date) {
		super();
		this.id = id;
		this.name = name;
		this.date = date;
	}
	public Student(Student s) {
		super();
		s.id = id;
		s.name = name;
		s.date = date;
	}
	
	public Student() {
		
	}
	
}
