package com.rest.spb.Student.controller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.rest.spb.Student")
//@ComponentScan("com.rest.spb.Student")
@EntityScan("com.rest.spb.Student")
public class StudentRestServiceAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentRestServiceAppApplication.class, args);
	}

}


/*
 * Follow MVC
@RestController
class StudentController{
	
	
	//@RequestMapping(method=RequestMethod.GET, path = "/getsid")
	@GetMapping("/getsid")
	public String getStudentName()
	{
		return "BhargaviMK";
	}
	
	@GetMapping(path = "/getsid/user/{name}")
	public StudentBean getStudentBean(@PathVariable String name)
	{
		return new StudentBean("Hi"+name);
	}
	
}


class StudentBean{
	
	String msg;
	
	public StudentBean(String msg) {
		
		this.msg=msg;
	}
	
	//getter method is mandatory for automatic conversion
	public String getMsg() {
		return msg;
	}
	
*/
	
