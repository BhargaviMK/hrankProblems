//package com.rest.spb.Student.service;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import org.springframework.stereotype.Service;
//
//import com.rest.spb.Student.model.Course;
//
//@Service
//public class CourseDaoService {
//	
//	private static List<Course> clist = new ArrayList<>();
//	
//	static {
//		clist.add(new Course(1, "Spring", "Ranga"));
//		clist.add(new Course(2, "SpringBoot", "Rao"));
//		clist.add(new Course(3, "MicroServices", "Karanam"));
//	}
//
//	public List<Course> findAll() {
//		return clist;
//	}
//
//	
//	
//}
