package com.rest.spb.Student.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Component;

import com.rest.spb.Student.model.Student;


//If you want your service bean to be managed by spring add below annotation
@Component
public class StudentDaoService {
	
	
	//I think I need to atowire CourseDaoService object instead of model object
	
	//declare with static modifier to access in static block
	private static List<Student> studentList = new ArrayList<>();
	
	//use static block to keep some data as begin step with out db
	static {
		studentList.add(new Student(1, "Ban1", new Date()));
		studentList.add(new Student(2, "Ban2", new Date()));
		studentList.add(new Student(3, "Ban3", new Date()));
		studentList.add(new Student(4, "Ban4", new Date()));		
	}
	
	int sidCount = 4;
	
	public List<Student> findAll()
	{
		return studentList;
	}
	
	public Student save(Student student)
	{
		if(student.getId() == null)
			student.setId(++sidCount);
		 studentList.add(student);
		 return student;
	}
	
	public Student findOne(int sid)
	{
		for(Student s: studentList) {
			if(s.getId() == sid)	
				return s;
			}
		return null;	
	}
	
	public Student deleteOne(int sid)
	{
		for(Student s: studentList) 
			if(s.getId() == sid) {
				Student stu = new Student(s); // new Student(s.getId(), s.getName(), s.getDate());
				studentList.remove(stu);
				return stu;
				}
	return null;
	//	Able to delete but getting below
		//Resolved [java.util.ConcurrentModificationException]
		
		//Use Iterator instead of foreach to avoid this.
		
//			Iterator it = studentList.iterator();
//			while(it.hasNext()) {
//				Student s = (Student) it.next();
//				if(s.getId() == sid)
//				{
//					it.remove();
//					return s;
//				}
//			}
//			
//			return null;
		
	}
	

}
