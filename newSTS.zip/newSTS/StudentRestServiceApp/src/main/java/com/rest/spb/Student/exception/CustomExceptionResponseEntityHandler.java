package com.rest.spb.Student.exception;

import java.util.Date;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.rest.spb.Student.service.StudentNotFoundException;

//used to handle the functionality for multiple controllers
@ControllerAdvice
@RestController
public class CustomExceptionResponseEntityHandler extends ResponseEntityExceptionHandler {

	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<Object> handleAllExceptions(Exception ex, WebRequest req)
	{
		return new ResponseEntity<>(new CustomExceptionResource(ex.getMessage(), req.getDescription(false), new Date()), HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ExceptionHandler(StudentNotFoundException.class)
	public ResponseEntity<Object> handleUserNotFoundException(StudentNotFoundException se, WebRequest req)
	{
		return new ResponseEntity<>(new CustomExceptionResource(se.getMessage(), req.getDescription(false), new Date()), HttpStatus.NOT_FOUND);

	}
	
	@Override
	public ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException mex,  HttpHeaders headers, HttpStatus status, WebRequest req) 
	{
		return new ResponseEntity<>(new CustomExceptionResource("Validation failed", mex.getBindingResult().toString(), new Date()), HttpStatus.BAD_REQUEST);

	}
	
}
