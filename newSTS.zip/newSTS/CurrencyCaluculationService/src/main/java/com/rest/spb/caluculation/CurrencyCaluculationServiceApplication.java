package com.rest.spb.caluculation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients("com.rest.spb.caluculation")
public class CurrencyCaluculationServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CurrencyCaluculationServiceApplication.class, args);
	}

}
