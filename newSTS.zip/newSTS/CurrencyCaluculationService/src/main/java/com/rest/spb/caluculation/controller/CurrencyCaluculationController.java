package com.rest.spb.caluculation.controller;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.rest.spb.caluculation.model.CurrencyConversion;
import com.rest.spb.caluculation.proxy.CurrencyExchangeServiceProxy;

@RestController
public class CurrencyCaluculationController{
	
	@Autowired
	private CurrencyExchangeServiceProxy proxy;
	
	@GetMapping("/currency-calculation/from/{from}/to/{to}/quantity/{quantity}")
	public CurrencyConversion caluculateCurrencyConversion(@PathVariable String from, @PathVariable String to, @PathVariable BigDecimal quantity)
	{
		//return new CurrencyConversion(1000L, "usd","inr", BigDecimal.ONE,100.0, 100*75.0,0);
		Map<String, String> uriVars= new HashMap<>();
		uriVars.put("from", from);
		uriVars.put("to", to);
		ResponseEntity<CurrencyConversion> resp = new RestTemplate().getForEntity("http://localhost:8000/currency-exchange/from/{from}/to/{to}", CurrencyConversion.class, uriVars);
		
		CurrencyConversion ccResult = resp.getBody();
		return new CurrencyConversion(ccResult.getId(),from, to, quantity,quantity.multiply(ccResult.getConversionMultiple()), ccResult.getConversionMultiple(),
				ccResult.getPort());

	}


	@GetMapping("/currency-calculation-feign/from/{from}/to/{to}/quantity/{quantity}")
	public CurrencyConversion caluculateCurrencyConversionFeign(@PathVariable String from, @PathVariable String to, @PathVariable BigDecimal quantity)
	{
		CurrencyConversion ccResult = proxy.retrieveExchangeValue(from, to);
		return new CurrencyConversion(ccResult.getId(),from, to, quantity,quantity.multiply(ccResult.getConversionMultiple()), ccResult.getConversionMultiple(),
				ccResult.getPort());

	}
}
