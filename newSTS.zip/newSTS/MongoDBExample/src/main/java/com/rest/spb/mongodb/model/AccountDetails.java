package com.rest.spb.mongodb.model;

import org.springframework.data.annotation.Id;

public class AccountDetails {
	
	public AccountDetails(int i) {
		// TODO Auto-generated constructor stub
		this.accNumber=i;
	}

	@Id
	public int accNumber;
	
}
