package com.rest.spb.mongodb.repo;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.rest.spb.mongodb.model.AccountDetails;

public interface AccountRepository extends MongoRepository<AccountDetails, Integer>{
	
	public AccountDetails  findById(int id) ;
	

}
